from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views import View
from sistemas_alojamiento_app.reservas_app.models import Reserva
from sistemas_alojamiento_app.reservas_app.forms import ReservaForm

from django.shortcuts import render

def sistema_unificado(request):
    """Vista principal o unificada del sistema"""
    return render(request, "sistema_unificado.html")

class SistemaUnificadoView(View):
    """ sistema unificado"""
    def get(self, request):
        html_content = """
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Sistema Unificado de Alojamientos</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container mt-5">
            <h1 class="text-center mb-5">🌐 Sistema Unificado de Alojamientos</h1>
            <h2 class="text-center mt-4">Bienvenido al Sistema 🏡</h2>
            <p class="lead text-center">Panel principal operativo en red local.</p>
            <hr>
            <div class="row g-4 mt-4">
                <div class="col-md-3"><a href="/clientes/lista/" class="btn btn-primary w-100 p-3">Clientes</a></div>
                <div class="col-md-3"><a href="/reservas/lista/" class="btn btn-success w-100 p-3">Reservas</a></div>
                <div class="col-md-3"><a href="/cabanas/lista/" class="btn btn-warning w-100 p-3 text-dark">Cabañas</a></div>
                <div class="col-md-3"><a href="/alojamientos/lista/" class="btn btn-danger w-100 p-3">Alojamientos</a></div>
            </div>
        </div>
        </body>
        </html>
        """
        return HttpResponse(html_content)

class CrearReservaView(View):
    def get(self, request):
        return render(request, "reserva_form.html")

    def post(self, request):
        form = ReservaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # Redirige limpiamente a la ruta principal

        return render(request, "reserva_form.html", {"form": form})


class RespuestaRootView(View):
    def get(self, request):
        return render(request, "inicio.html")


class DashboardView(View):
    def get(self, request):
        return render(request, "dashboard.html")


class InicioView(View):
    def get(self, request):
        return render(request, "inicio.html")


class AyudaView(View):
    def get(self, request):
        return render(request, "ayuda.html")


class ContactoView(View):
    def get(self, request):
        return render(request, "contacto.html")

