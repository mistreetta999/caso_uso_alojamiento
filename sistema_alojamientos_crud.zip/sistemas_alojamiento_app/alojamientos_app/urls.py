"""URLs de la aplicación alojamientos_app."""

from django.urls import path
from django.views.generic import TemplateView

from . import views


app_name = "alojamientos_app"


urlpatterns = [
    # ======================================================
    # PÁGINA PRINCIPAL
    # ======================================================
    path(
        "",
        views.sistema_unificado,
        name="sistema_unificado",
    ),

    path(
        "sistema-unificado/",
        TemplateView.as_view(
            template_name="sistema_alojamiento/sistema_unificado.html"
        ),
        name="alojamientos_app_html",
    ),

    # ======================================================
    # VISTAS PRINCIPALES
    # ======================================================
    path(
        "inicio/",
        views.InicioView.as_view(),
        name="inicio",
    ),

    path(
        "home/",
        views.HomeView.as_view(),
        name="home",
    ),

    path(
        "dashboard/",
        views.DashboardView.as_view(),
        name="dashboard",
    ),

    path(
        "dashboard-view/",
        views.DashboardView.as_view(),
        name="dashboard_view",
    ),

    path(
        "lista-alojamientos/",
        views.lista_alojamientos,
        name="lista_alojamientos",
    ),

    # ======================================================
    # CRUD DE ALOJAMIENTOS
    # ======================================================
    path(
        "lista/",
        views.AlojamientoListView.as_view(),
        name="alojamiento_list",
    ),

    path(
        "crear/",
        views.AlojamientoCreateView.as_view(),
        name="crear_alojamiento",
    ),

    path(
        "nuevo/",
        views.AlojamientoCreateView.as_view(),
        name="nuevo_alojamiento",
    ),

    path(
        "<int:pk>/",
        views.AlojamientoDetailView.as_view(),
        name="alojamiento_detail",
    ),

    path(
        "<int:pk>/detalle/",
        views.AlojamientoDetailView.as_view(),
        name="detalle_alojamiento",
    ),

    path(
        "<int:pk>/editar/",
        views.AlojamientoUpdateView.as_view(),
        name="editar_alojamiento",
    ),

    path(
        "<int:pk>/eliminar/",
        views.AlojamientoDeleteView.as_view(),
        name="alojamiento_delete",
    ),

    # ======================================================
    # PÁGINAS ESTÁTICAS Y PLANTILLAS
    # ======================================================
    path(
        "alojamiento/",
        TemplateView.as_view(
            template_name="alojamientos_app/alojamientos_app.html"
        ),
        name="alojamientos_app_home",
    ),

    path(
        "base/",
        TemplateView.as_view(
            template_name="alojamientos_app/base.html"
        ),
        name="base_view",
    ),

    path(
        "bootstrap/",
        TemplateView.as_view(
            template_name="alojamientos_app/bootstrap.html"
        ),
        name="bootstrap_view",
    ),

    path(
        "editar/",
        TemplateView.as_view(
            template_name="alojamientos_app/editar.html"
        ),
        name="editar",
    ),

    path(
        "detalle/",
        TemplateView.as_view(
            template_name="alojamientos_app/detalle.html"
        ),
        name="detalle",
    ),

    path(
        "detalle-alojamiento/",
        TemplateView.as_view(
            template_name="alojamientos_app/detalle_alojamiento.html"
        ),
        name="detalle_alojamiento_estatico",
    ),

    path(
        "global/",
        TemplateView.as_view(
            template_name="alojamientos_app/global.html"
        ),
        name="global_view",
    ),

    path(
        "index/",
        TemplateView.as_view(
            template_name="alojamientos_app/index.html"
        ),
        name="index_alojamientos",
    ),

    path(
        "nuevo-estatico/",
        TemplateView.as_view(
            template_name="alojamientos_app/nuevo.html"
        ),
        name="nuevo_estatico",
    ),

    # ======================================================
    # PLANTILLAS ANTIGUAS CONSERVADAS
    # ======================================================
    path(
        "alojamiento-app/lista/",
        TemplateView.as_view(
            template_name="alojamiento_list.html"
        ),
        name="alojamiento_list_static",
    ),

    path(
        "alojamiento-app/detalle/",
        TemplateView.as_view(
            template_name="alojamiento.html"
        ),
        name="alojamiento_static",
    ),

    path(
        "alojamiento-app/dashboard/",
        TemplateView.as_view(
            template_name="desabord.html"
        ),
        name="desabord_static",
    ),

    path(
        "alojamiento-app/global/",
        TemplateView.as_view(
            template_name="global.html"
        ),
        name="global_static",
    ),

    path(
        "alojamiento-app/base/",
        TemplateView.as_view(
            template_name="base.html"
        ),
        name="base_static",
    ),

    path(
        "alojamiento-app/bootstrap/",
        TemplateView.as_view(
            template_name="boostrap.html"
        ),
        name="bootstrap_static",
    ),

    path(
        "alojamiento-app/lista-alternativa/",
        TemplateView.as_view(
            template_name="lista_alojamiento.html"
        ),
        name="lista_alojamiento_static",
    ),
]