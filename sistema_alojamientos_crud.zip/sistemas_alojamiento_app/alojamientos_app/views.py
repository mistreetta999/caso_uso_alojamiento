"""Vistas de la aplicación de alojamientos."""

from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, DetailView, CreateView, UpdateView, DeleteView
from rest_framework import routers, viewsets

from .models import Alojamiento
from .serializers import AlojamientoSerializer
from .forms import AlojamientoForm

"""Vistas de la aplicación de alojamientos."""

from django.shortcuts import get_object_or_404
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from rest_framework import viewsets

from .models import Alojamiento
from .serializers import AlojamientoSerializer
from .forms import AlojamientoForm


# 1. API REST ViewSet
class AlojamientoViewSet(viewsets.ModelViewSet):
    """API REST para gestionar alojamientos."""
    queryset = Alojamiento.objects.all()
    serializer_class = AlojamientoSerializer


# 2. Vistas Basadas en Clases (CRUD completo)
class AlojamientoListView(ListView):
    """Muestra el listado de alojamientos."""
    model = Alojamiento
    template_name = "alojamientos_app/lista_alojamientos.html"
    context_object_name = "alojamientos"


class AlojamientoDetailView(DetailView):
    """Muestra el detalle de un alojamiento."""
    model = Alojamiento
    template_name = "alojamientos_app/detalle_alojamiento.html"
    context_object_name = "alojamiento"


class AlojamientoCreateView(CreateView):
    """Crea un nuevo alojamiento."""
    model = Alojamiento
    form_class = AlojamientoForm
    template_name = "alojamientos_app/crear.html"


class AlojamientoUpdateView(UpdateView):
    """Actualiza un alojamiento existente."""
    model = Alojamiento
    form_class = AlojamientoForm
    template_name = "alojamientos_app/editar.html"


class AlojamientoDeleteView(DeleteView):
    """Elimina un alojamiento."""
    model = Alojamiento
    template_name = "alojamientos_app/alojamientos_app.html"
# --- API REST exclusiva de Alojamientos ---
class AlojamientoViewSet(viewsets.ModelViewSet):
    """API REST para alojamientos."""
    queryset = Alojamiento.objects.all()
    serializer_class = AlojamientoSerializer


def get_router():
    """Función de utilidad para el router de la API (si se requiere externamente)."""
    from sistemas_alojamiento_app.reservas_app.views import ReservaViewSet
    from sistemas_alojamiento_app.clientes_app.views import ClienteViewSet
    from sistemas_alojamiento_app.cabanas_app.views import CabanaViewSet
    
    router = routers.DefaultRouter()
    router.register(r'reservas', ReservaViewSet)
    router.register(r'clientes', ClienteViewSet)
    router.register(r'cabanas', CabanaViewSet)
    router.register(r'alojamientos', AlojamientoViewSet)
    return router


# --- Vistas de páginas generales y Dashboards ---
class InicioView(TemplateView):
    """Vista de la página de inicio (index)."""
    template_name = "alojamientos_app/index.html"


class HomeView(TemplateView):
    """Vista de la página principal de la app."""
    template_name = "alojamientos_app/alojamientos_app.html"


class DashboardView(TemplateView):
    """Vista del panel de control general."""
    template_name = "alojamientos_app/dashboard.html"


class SistemaUnificadoView(TemplateView):
    """Vista del sistema unificado con listado de alojamientos."""
    template_name = "alojamientos_app/alojamientos_app.html"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["alojamientos"] = Alojamiento.objects.all()
        return contexto


# --- Vistas Basadas en Funciones Auxiliares ---
def sistema_unificado(request: HttpRequest) -> HttpResponse:
    """Vista basada en función para el sistema unificado."""
    alojamientos = Alojamiento.objects.all()
    return render(request, "alojamientos_app/alojamientos_app.html", {"alojamientos": alojamientos})


def dashboard(request: HttpRequest) -> HttpResponse:
    """Vista basada en función para el dashboard."""
    return render(request, "alojamientos_app/dashboard.html")


def lista_alojamientos(request: HttpRequest) -> HttpResponse:
    """Vista basada en función para listar alojamientos."""
    alojamientos = Alojamiento.objects.all()
    return render(request, 'alojamientos_app/lista_alojamientos.html', {'alojamientos': alojamientos})


def respuesta_root(request: HttpRequest) -> HttpResponse:
    """Vista de respuesta raíz."""
    return render(request, "alojamientos_app/base.html")


# --- CRUD Completo con Vistas Genéricas (Vinculado a tus templates y formularios) ---

class AlojamientoListView(ListView):
    """Lista todos los alojamientos."""
    model = Alojamiento
    template_name = "alojamientos_app/lista_alojamientos.html"
    context_object_name = "alojamientos"


class AlojamientoDetailView(DetailView):
    """Muestra el detalle de un alojamiento específico."""
    model = Alojamiento
    template_name = "alojamientos_app/detalle_alojamiento.html"
    context_object_name = "alojamiento"


class AlojamientoCreateView(CreateView):
    """Permite crear un nuevo alojamiento mediante formulario."""
    model = Alojamiento
    form_class = AlojamientoForm
    template_name = "alojamientos_app/crear.html"  # O puedes usar 'alojamientos_app/nuevo.html'
    success_url = reverse_lazy('lista_alojamientos')


class AlojamientoUpdateView(UpdateView):
    """Permite editar un alojamiento existente."""
    model = Alojamiento
    form_class = AlojamientoForm
    template_name = "alojamientos_app/editar.html"
    success_url = reverse_lazy('lista_alojamientos')


class AlojamientoDeleteView(DeleteView):
    """Permite confirmar y eliminar un alojamiento."""
    model = Alojamiento
    template_name = "alojamientos_app/alojamientos_app.html"  
    success_url = reverse_lazy('lista_alojamientos')