from django.db import models

# cabanas_app/models.py
class Cabana(models.Model):
    nombre = models.CharField(max_length=100)
    capacidad = models.IntegerField()
    descripcion = models.TextField()
    disponible = models.BooleanField(default=True)  # campo esperado

    def __str__(self):
        return f"{self.nombre} (capacidad: {self.capacidad})"

