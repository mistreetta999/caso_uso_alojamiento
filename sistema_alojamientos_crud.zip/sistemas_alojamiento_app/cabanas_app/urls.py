"""URLs de la aplicación cabanas_app."""

from django.urls import path
from django.views.generic import TemplateView

from .views import (
    CabanaListView,
    CabanaDetailView,
    CabanaCreateView,
    CabanaUpdateView,
    CabanaDeleteView,
)


app_name = "cabanas_app"


urlpatterns = [
 path('', TemplateView.as_view(template_name='sistema_alojamiento/sistema_unificado.html'), name='sistema_unificado.html'),
    path(
        "",
        CabanaListView.as_view(),
        name="lista_cabanas",
    ),

    path(
        "listar/",
        CabanaListView.as_view(),
        name="listar_cabanas",
    ),

    path(
        "nuevo/",
        CabanaCreateView.as_view(),
        name="nuevo_cabana",
    ),

    path(
        "crear/",
        CabanaCreateView.as_view(),
        name="crear_cabana",
    ),

    path(
        "<int:pk>/",
        CabanaDetailView.as_view(),
        name="detalle_cabana",
    ),

    path(
        "<int:pk>/detalle/",
        CabanaDetailView.as_view(),
        name="detalle_cabana_alt",
    ),

    path(
        "<int:pk>/editar/",
        CabanaUpdateView.as_view(),
        name="editar_cabana",
    ),

    path(
        "actualizar/<int:pk>/",
        CabanaUpdateView.as_view(),
        name="actualizar_cabana",
    ),

    path(
        "<int:pk>/eliminar/",
        CabanaDeleteView.as_view(),
        name="eliminar_cabana",
    ),

    path(
        "eliminar/<int:pk>/",
        CabanaDeleteView.as_view(),
        name="eliminar_cabana_alt",
    ),

    # ======================================================
    # PÁGINAS ESTÁTICAS DE LA APLICACIÓN
    # ======================================================
    path(
        "editar/",
        TemplateView.as_view(
            template_name="cabanas_app/editar_cabanas.html"
        ),
        name="editar_cabanas",
    ),

    path(
        "crear-estatico/",
        TemplateView.as_view(
            template_name="cabanas_app/crear_cabanas.html"
        ),
        name="crear_cabanas_estatico",
    ),

    path(
        "dashboard/",
        TemplateView.as_view(
            template_name="cabanas_app/desabord.html"
        ),
        name="dashboard_cabanas",
    ),

    path(
        "global/",
        TemplateView.as_view(
            template_name="cabanas_app/global.html"
        ),
        name="global_cabanas",
    ),

    path(
        "base/",
        TemplateView.as_view(
            template_name="cabanas_app/base.html"
        ),
        name="base_cabanas",
    ),

    path(
        "bootstrap/",
        TemplateView.as_view(
            template_name="cabanas_app/boostrap.html"
        ),
        name="bootstrap_cabanas",
    ),

    path(
        "nueva/",
        TemplateView.as_view(
            template_name="cabanas_app/nueva.html"
        ),
        name="nueva_cabanas",
    ),

    path(
        "sistema-unificado/",
        TemplateView.as_view(
            template_name="sistema_alojamiento/sistema_unificado.html"
        ),
        name="sistema_unificado",
    ),
]