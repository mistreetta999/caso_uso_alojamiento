"""Vistas de la aplicación de cabañas."""

from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpRequest
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from rest_framework import viewsets

from .models import Cabana
from .serializers import CabanaSerializer 
from .forms import CabanaForm  

def CabanaViewSet(request: HttpRequest) -> HttpResponse:
    """Vista de ejemplo para el ViewSet de cabañas (no utilizada directamente)."""
    return HttpResponse("Este endpoint está gestionado por el ViewSet de DRF.")



def lista_cabanas(request: HttpRequest) -> HttpResponse:
    """Muestra la lista de todas las cabañas."""
    cabanas = Cabana.objects.all()
    return render(request, "cabanas_app/listar_cabanas.html", {"cabanas": cabanas})


def detalle_cabana(request: HttpRequest, id: int) -> HttpResponse:
    """Muestra el detalle de una cabaña específica usando su ID."""
    cabana = get_object_or_404(Cabana, pk=id)
    return render(request, "cabanas_app/detalle.html", {"cabana": cabana})


def nueva_cabana(request: HttpRequest) -> HttpResponse:
    """Vista basada en función para crear una nueva cabaña manualmente."""
    if request.method == "POST":
        nombre = request.POST.get("nombre")
        descripcion = request.POST.get("descripcion")
        capacidad = request.POST.get("capacidad")
        
        Cabana.objects.create(
            nombre=nombre,
            descripcion=descripcion,
            capacidad=capacidad
        )
        # Redirige a la lista de cabañas usando el namespace correcto
        return redirect("cabanas_app:listar_cabanas")
        
    return render(request, "cabanas_app/nueva.html")


def index(request: HttpRequest) -> HttpResponse:
    """Vista de índice para cabañas."""
    cabanas = Cabana.objects.all()
    return render(request, "cabanas_app/global/global/index.html", {"cabanas": cabanas})


def respuesta_root(request: HttpRequest) -> HttpResponse:
    """Vista de respuesta raíz general."""
    return render(request, "respuesta_root.html")


# ---------------------------------------------------------
# 2. CRUD Completo con Vistas Genéricas (Recomendado)
# ---------------------------------------------------------

class CabanaListView(ListView):
    """Lista todas las cabañas utilizando vistas genéricas de Django."""
    model = Cabana
    template_name = "cabanas_app/listar_cabanas.html"
    context_object_name = "cabanas"


class CabanaDetailView(DetailView):
    """Muestra el detalle completo de una cabaña por su primary key (pk)."""
    model = Cabana
    template_name = "cabanas_app/detalle.html"
    context_object_name = "cabana"


class CabanaCreateView(CreateView):
    """Procesa el formulario para crear una nueva cabaña."""
    model = Cabana
    fields = ["nombre", "descripcion", "capacidad"]
    template_name = "cabanas_app/crear_cabanas.html"
    success_url = reverse_lazy("cabanas_app:listar_cabanas")


class CabanaUpdateView(UpdateView):
    """Procesa el formulario para actualizar una cabaña existente."""
    model = Cabana
    fields = ["nombre", "descripcion", "capacidad"]
    template_name = "cabanas_app/editar_cabanas.html"
    success_url = reverse_lazy("cabanas_app:listar_cabanas")


class CabanaDeleteView(DeleteView):
    """Confirma y elimina una cabaña del sistema."""
    model = Cabana
    template_name = "cabanas_app/eliminar.html"
    success_url = reverse_lazy("cabanas_app:listar_cabanas")


# ---------------------------------------------------------
# 3. ViewSet para la API REST
# ---------------------------------------------------------

