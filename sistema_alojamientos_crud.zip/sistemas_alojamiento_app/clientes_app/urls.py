"""URLs de la aplicación clientes_app."""

from django.urls import include, path
from django.views.generic import TemplateView
from rest_framework.routers import DefaultRouter

from . import views


app_name = "clientes_app"


# ==========================================================
# ROUTER DE LA API REST
# ==========================================================

router = DefaultRouter()

router.register(
    r"clientes",
    views.ClienteViewSet,
    basename="cliente-api",
)

router.register(
    r"reservas",
    views.ReservaViewSet,
    basename="reserva-api",
)


# ==========================================================
# RUTAS DE CLIENTES, DASHBOARD Y API
# ==========================================================

urlpatterns = [
    # ------------------------------------------------------
    # PÁGINA PRINCIPAL / PANEL DEL SISTEMA
    # ------------------------------------------------------
    path('', TemplateView.as_view(template_name='sistema_alojamiento/sistema_unificado.html'), name='sistema_unificado.html'),
    path(
        "",
        TemplateView.as_view(
            template_name="sistema_alojamiento/sistema_unificado.html"
        ),
        name="sistema_unificado",
    ),

    path(
        "sistema-unificado/",
        TemplateView.as_view(
            template_name="sistema_alojamiento/sistema_unificado.html"
        ),
        name="sistema-unificado",
    ),

    path(
        "dashboard/",
        views.dashboard,
        name="dashboard",
    ),

    path(
        "respuesta-root/",
        views.respuesta_root,
        name="respuesta-root",
    ),

    path(
        "sistema/",
        views.sistema_unificado,
        name="sistema",
    ),

    # ------------------------------------------------------
    # GESTIÓN HTML DE CLIENTES
    # ------------------------------------------------------
    path(
        "lista/",
        views.ClienteListView.as_view(),
        name="lista",
    ),

    path(
        "crear/",
        views.crear_cliente,
        name="crear_cliente",
    ),

    path(
        "create/",
        views.ClienteCreateView.as_view(),
        name="create",
    ),

    path(
        "detalle/<int:cliente_id>/",
        views.cliente_detalles,
        name="detalles",
    ),

    path(
        "update/<int:pk>/",
        views.ClienteUpdateView,
        name="update",
    ),

    path(
        "delete/<int:pk>/",
        views.ClienteDeleteView,
        name="delete",
    ),

    # ------------------------------------------------------
    # PLANTILLAS ADICIONALES QUE YA TENÍAS
    # ------------------------------------------------------
    path(
        "editar/",
        TemplateView.as_view(template_name="editar.html"),
        name="editar",
    ),

    path(
        "index/",
        TemplateView.as_view(template_name="index.html"),
        name="index-template",
    ),

    path(
        "clientes/",
        TemplateView.as_view(template_name="clientes.html"),
        name="clientes-template",
    ),

    path(
        "detalle/",
        TemplateView.as_view(template_name="detalle.html"),
        name="detalle-template",
    ),

    path(
        "desabord/",
        TemplateView.as_view(template_name="desabord.html"),
        name="desabord",
    ),

    path(
        "global/",
        TemplateView.as_view(template_name="global.html"),
        name="global",
    ),

    path(
        "base/",
        TemplateView.as_view(template_name="base.html"),
        name="base",
    ),

    path(
        "boostrap/",
        TemplateView.as_view(template_name="boostrap.html"),
        name="boostrap",
    ),

    path(
        "clientes_list/",
        TemplateView.as_view(template_name="clientes_list.html"),
        name="clientes_list",
    ),

    path(
        "nuevo/",
        TemplateView.as_view(template_name="nuevo.html"),
        name="nuevo",
    ),

    # ------------------------------------------------------
    # API REST
    # ------------------------------------------------------
    path(
        "api/",
        include(router.urls),
    ),
]