"""Vistas de la aplicación de clientes."""

from django.apps import apps
from django.http import HttpRequest, HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import CreateView, ListView

from rest_framework import viewsets

from sistemas_alojamiento_app.reservas_app.serializers import ReservaSerializer

from .forms import ClienteForm
from .models import Cliente
from .serializers import ClienteSerializer


# Se obtiene el modelo Reserva sin crear problemas de importación circular.
Reserva = apps.get_model("reservas_app", "Reserva")


# ==========================================================
# VISTAS HTML DE CLIENTES
# ==========================================================

def index(request: HttpRequest) -> HttpResponse:
    """Página principal del módulo de clientes."""
    return HttpResponse("Clientes")


def clientes_views(
    request: HttpRequest,
) -> HttpResponseRedirect | HttpResponse:
    """Respuesta simple para la sección de clientes."""
    return HttpResponse("Clientes")


class ClientesViewSet(View):
    """Vista HTML del detalle de un cliente."""

    def get(self, request: HttpRequest, cliente_id: int) -> HttpResponse:
        cliente = get_object_or_404(Cliente, id=cliente_id)

        return render(
            request,
            "cliente_detalles.html",
            {"cliente": cliente},
        )


def cliente_detalles(request: HttpRequest, cliente_id: int) -> HttpResponse:
    """Muestra el detalle de un cliente."""
    cliente = get_object_or_404(Cliente, id=cliente_id)

    return render(
        request,
        "cliente_detalles.html",
        {"cliente": cliente},
    )


def crear_cliente(
    request: HttpRequest,
) -> HttpResponseRedirect | HttpResponse:
    """Formulario para crear un nuevo cliente."""

    if request.method == "POST":
        form = ClienteForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect("index")
    else:
        form = ClienteForm()

    return render(
        request,
        "clientes_app/cliente_form.html",
        {"form": form},
    )


def ClienteUpdateView(
    request: HttpRequest,
    pk: int,
) -> HttpResponseRedirect | HttpResponse:
    """Actualiza los datos de un cliente."""

    cliente = get_object_or_404(Cliente, pk=pk)

    if request.method == "POST":
        form = ClienteForm(request.POST, instance=cliente)

        if form.is_valid():
            form.save()
            return redirect("index")
    else:
        form = ClienteForm(instance=cliente)

    return render(
        request,
        "actualizar_cliente.html",
        {
            "form": form,
            "cliente": cliente,
        },
    )


def ClienteDeleteView(
    request: HttpRequest,
    pk: int,
) -> HttpResponseRedirect | HttpResponse:
    """Elimina un cliente existente."""

    cliente = get_object_or_404(Cliente, pk=pk)

    if request.method == "POST":
        cliente.delete()
        return redirect("index")

    return render(
        request,
        "eliminar_cliente.html",
        {"cliente": cliente},
    )


class ClienteCreateView(CreateView):
    """Vista basada en clase para crear un cliente."""

    model = Cliente
    fields = ["nombre", "email", "telefono"]
    template_name = "clientes_app/cliente_form.html"
    success_url = reverse_lazy("clientes:lista")


class ClienteListView(ListView):
    """Lista los clientes activos."""

    model = Cliente
    template_name = "clientes/list.html"
    context_object_name = "clientes"

    def get_queryset(self):
        return Cliente.objects.filter(activo=True)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["clientes_activos"] = Cliente.objects.filter(activo=True)
        return context


# ==========================================================
# DASHBOARD Y VISTAS GENERALES
# ==========================================================

def dashboard(request: HttpRequest) -> HttpResponse:
    """Dashboard principal del sistema de alojamientos."""

    clientes = Cliente.objects.all().order_by("-id")

    contexto = {
        "cantidad_clientes": clientes.count(),
        "clientes_recientes": clientes[:5],
    }

    return render(
        request,
        "global/global/dashboard.html",
        contexto,
    )


def respuesta_root(request: HttpRequest) -> HttpResponse:
    """Vista raíz de respuesta."""
    return render(request, "respuesta_root.html")


def sistema_unificado(request: HttpRequest) -> HttpResponse:
    """Vista principal del sistema unificado."""
    return render(request, "sistema_unificado.html")


# ==========================================================
# API REST
# ==========================================================

class ClienteViewSet(viewsets.ModelViewSet):
    """API REST para clientes."""

    queryset = Cliente.objects.all()
    serializer_class = ClienteSerializer


class ReservaViewSet(viewsets.ModelViewSet):
    """API REST para reservas relacionadas con clientes."""

    queryset = Reserva.objects.select_related(
        "cliente",
        "cabana",
    ).all()

    serializer_class = ReservaSerializer