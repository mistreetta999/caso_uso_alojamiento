"""URLs de la aplicación reservas_app."""

# cspell:ignore ReservaViewSet
from django.urls import include, path
from django.views.generic import TemplateView
from rest_framework.routers import DefaultRouter
from .views import (
    ReservaViewSet,
    crear_reserva,
    detalle_reserva,
    editar_reserva,
    eliminar_reserva,
    index,
    lista_reservas,
    reservas_app_view,
)


app_name = "reservas_app"


# ==========================================================
# ROUTER DE LA API REST
# ==========================================================

router = DefaultRouter()

# El router recibe únicamente clases ViewSet.
router.register(
    r"reservas",
    ReservaViewSet,
    basename="api-reservas",
)


# ==========================================================
# RUTAS DE LA APLICACIÓN
# ==========================================================

urlpatterns = [
        path('sistema_unificado/', TemplateView.as_view   (template_name='sistema_alojamiento/sistema_unificado.html'), name='sistema_unificado.html'),
        
        
        
        
    path(
        "",
        reservas_app_view,
        name="reservas_app_view",
    ),

    path(
        "inicio/",
        index,
        name="reservas_index",
    ),

    path(
        "lista/",
        lista_reservas,
        name="lista_reservas",
    ),

    path(
        "crear/",
        crear_reserva,
        name="crear_reserva",
    ),

    path(
        "<int:pk>/",
        detalle_reserva,
        name="detalle_reserva",
    ),

    path(
        "<int:pk>/editar/",
        editar_reserva,
        name="editar_reserva",
    ),

    path(
        "<int:pk>/eliminar/",
        eliminar_reserva,
        name="eliminar_reserva",
    ),

    # ------------------------------------------------------
    # PLANTILLAS QUE YA TENÍAS EN EL PROYECTO
    # ------------------------------------------------------
    path(
        "pagina-inicio/",
        TemplateView.as_view(template_name="index.html"),
        name="inicio",
    ),

    path(
        "crear-cliente/",
        TemplateView.as_view(template_name="crear_cliente.html"),
        name="crear_cliente_template",
    ),

    path(
        "clientes/",
        TemplateView.as_view(template_name="clientes.html"),
        name="clientes",
    ),

    path(
        "editar/",
        TemplateView.as_view(template_name="editar.html"),
        name="editar",
    ),

    path(
        "detalle/",
        TemplateView.as_view(template_name="detalle.html"),
        name="detalle",
    ),

    path(
        "desabord/",
        TemplateView.as_view(template_name="desabord.html"),
        name="desabord",
    ),

    path(
        "global/",
        TemplateView.as_view(template_name="global.html"),
        name="global",
    ),

    path(
        "base/",
        TemplateView.as_view(template_name="base.html"),
        name="base",
    ),

    path(
        "boostrap/",
        TemplateView.as_view(template_name="boostrap.html"),
        name="boostrap",
    ),

    path(
        "clientes-list/",
        TemplateView.as_view(template_name="clientes_list.html"),
        name="clientes_list",
    ),

    path(
        "nueva/",
        TemplateView.as_view(template_name="nueva.html"),
        name="nueva",
    ),

    # ------------------------------------------------------
    # API REST DE RESERVAS
    # ------------------------------------------------------
    path(
        "api/",
        include(router.urls),
    ),

    # Endpoint directo compatible para listar reservas.
    path(
        "api/vistas/reservas/",
        ReservaViewSet.as_view({"get": "list"}),
        name="reserva_list",
    ),
]