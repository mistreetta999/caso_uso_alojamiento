from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from rest_framework import viewsets

from .forms import ReservaForm
from .models import Reserva
from .serializers import ReservaSerializer
from rest_framework import viewsets
from .forms import ReservaForm
from .serializers import ReservaSerializer



# ---------------------------------
# Vistas generales
# ---------------------------------

def reservas_app_view(request):
    return render(request, "sistema_alojamiento/sistema_unificado.html")


def sistema_unificado(request):
    return render(request, "sistema_unificado.html")


def dashboard(request):
    return render(request, "global/global/dashboard.html")


def index(request):
    return HttpResponse("Alojamientos")


# ---------------------------------
# CRUD completo de reservas
# ---------------------------------

def lista_reservas(request):
    reservas = Reserva.objects.select_related(
        "cliente",
        "cabana",
        "alojamiento",
    ).all()

    return render(
        request,
        "reservas/lista_reservas.html",
        {
            "reservas": reservas,
        },
    )


def detalle_reserva(request, pk):
    reserva = get_object_or_404(
        Reserva.objects.select_related(
            "cliente",
            "cabana",
            "alojamiento",
        ),
        pk=pk,
    )

    return render(
        request,
        "reservas/detalle_reserva.html",
        {
            "reserva": reserva,
        },
    )


def crear_reserva(request):
    if request.method == "POST":
        form = ReservaForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect("reservas_app:lista_reservas")
    else:
        form = ReservaForm()

    return render(
        request,
        "reservas/crear_reserva.html",
        {
            "form": form,
            "titulo": "Crear reserva",
        },
    )


def editar_reserva(request, pk):
    reserva = get_object_or_404(Reserva, pk=pk)

    if request.method == "POST":
        form = ReservaForm(
            request.POST,
            instance=reserva,
        )

        if form.is_valid():
            form.save()
            return redirect("reservas_app:lista_reservas")
    else:
        form = ReservaForm(instance=reserva)

    return render(
        request,
        "reservas/editar_reserva.html",
        {
            "form": form,
            "reserva": reserva,
            "titulo": "Editar reserva",
        },
    )


def eliminar_reserva(request, pk):
    reserva = get_object_or_404(Reserva, pk=pk)

    if request.method == "POST":
        reserva.delete()
        return redirect("reservas_app:lista_reservas")

    return render(
        request,
        "reservas/eliminar_reserva.html",
        {
            "reserva": reserva,
        },
    )


# ---------------------------------
# API REST: CRUD completo de reservas
# GET, POST, PUT, PATCH y DELETE
# ---------------------------------

class ReservaViewSet(viewsets.ModelViewSet):
    queryset = Reserva.objects.select_related(
        "cliente",
        "cabana",
        "alojamiento",
    ).all()

    serializer_class = ReservaSerializer

    http_method_names = [
        "get",
        "post",
        "put",
        "patch",
        "delete",
    ]