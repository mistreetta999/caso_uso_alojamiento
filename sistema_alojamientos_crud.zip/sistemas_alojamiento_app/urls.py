from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from django.shortcuts import render
from rest_framework import routers  
from rest_framework.routers import DefaultRouter
from sistema_alojamientos_app.cabanas_app.views import CabanaViewSet
from sistema_alojamientos_app.alojamientos_app.views import AlojamientoViewSet
from sistema_alojamientos_app.clientes_app.views import CliesteViewSet
from reservas_app.views import ReservaViewSet
from clientes_app.views import ClientesViewSet
from .views import AlojamientoViewsSet

def get_router():
    router = routers.DefaultRouter()
    router.register(r'reservas', ReservaViewSet)
    router.register(r'clientes', ClienteViewSet)
    router.register(r'cabanas', CabanaViewSet)
    router.register(r'alojamientos', AlojamientoViewSet)
    return router
# Configuración del Router de la API REST
router = routers.DefaultRouter()
router.register(r'reservas', ReservaViewSet, basename='api_reservas')
router.register(r'clientes', ClienteViewSet, basename='api_clientes')
router.register(r'cabanas', CabanaViewSet, basename='api_cabanas')
router.register(r'alojamientos', AlojamientoViewSet, basename='api_alojamientos')   

def cabana_views_set(request):
    return render(request, "cabanas.html")

urlpatterns = [
       path("clientes/", include("sistemas_alojamiento_app.clientes_app.urls")),
    path("reservas/", include("sistemas_alojamiento_app.reservas_app.urls")),
    path("cabanas/", include("sistemas_alojamiento_app.cabanas_app.urls")),
    path("alojamientos/", include("sistemas_alojamiento_app.alojamientos_app.urls")),
]
path('reservas_app/',include("sistemas_alojamiento_app.reservas_app.urls"))
    path('', include(router.urls)),
    path('clientes/', include('sistemas_alojamiento_app.clientes_app.urls')),
    path('reservas/', include('sistemas_alojamiento_app.reservas_app.urls')),
    path('cabanas/', include('sistemas_alojamiento_app.cabanas_app.urls')),
    path('alojamientos/', include('sistemas_alojamiento_app.alojamientos_app.urls')),
    path('reservas_app/',TemplateView.as_view(template_name="editar.html")),
    path('reservas_app/',TemplateView.as_view(template_name="index.html")),
    path('reservas_app/',TemplateView.as_view(template_name="crear_cliente.html")),
    path('reservas_app/',TemplateView.as_view(template_name="clientes.html")),
    path('reservas_app/',TemplateView.as_view(template_name="editar.html")),
    path('reservas_app/',TemplateView.as_view(template_name="detalle.html")),
    path('reservass_app/',TemplateView.as_view(template_name="desabord.html")),
    path('reservas _app/',TemplateView.as_view(template_name="global.html")),
    path('reservas _app/',TemplateView.as_view(template_name="base.html")),
    path('reservas_app/',TemplateView.as_view(template_name="boostrap.html")),
    path('reservas_app/',TemplateView.as_view(template_name="reservas_list.html")),
    path('reservas_app/',TemplateView.as_view(template_name="nuevo.html")),
    # 1. Rutas de la API REST
    path("admin/", admin.site.urls),
    path("api/", include(router.urls)),

    # Dashboard global
    path("", dashboard, name="dashboard"),
    path("inicio/", inicio, name="inicio"),
    path("sistema/", sistema_unificado, name="sistema_unificado"),

    # CRUD alojamientos
    path("alojamientos/nuevo/", crear_alojamiento, name="crear_alojamiento"),

    # Apps del sistema (Asegurando que coincidan con las carpetas con sufijo _app)
    path("alojamientos_app/", include("alojamientos_app.urls")),
    path("cabanas_app/", include("cabanas_app.urls")),
    path("reservas_app/", include("reservas_app.urls")),
    path("clientes_app/", include("clientes_app.urls")),
    path('alojamientos/', include('alojamientos_app.urls')),
    path('cabanas/', include('cabanas.urls')),
    path('clientes/', include('clientes.urls')),
    path('reservas/', include('reservas.urls')),
]
