"""
Vista unificada general del sistema.
Combina todos los ViewSets de la API REST y las funciones/clases 
necesarias para cubrir absolutamente todas las rutas que me pasaste.
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpRequest, HttpResponse
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, DetailView, CreateView, UpdateView, DeleteView
from rest_framework import viewsets

# -------------------------------------------------------------------------
# 1. VIEWSETS PARA LA API REST (Alojamientos, Cabañas, Clientes, Reservas)
# -------------------------------------------------------------------------

try:
    from alojamientos_app.models import Alojamiento
    from alojamientos_app.serializers import AlojamientoSerializer
    from alojamientos_app.forms import AlojamientoForm
except ImportError:
    Alojamiento = AlojamientoSerializer = AlojamientoForm = None

try:
    from cabanas_app.models import Cabana
    from cabanas_app.serializers import CabanaSerializer
    from cabanas_app.forms import CabanaForm
except ImportError:
    Cabana = CabanaSerializer = CabanaForm = None

try:
    from clientes_app.models import Cliente
    from clientes_app.serializers import ClienteSerializer
    from clientes_app.forms import ClienteForm
except ImportError:
    Cliente = ClienteSerializer = ClienteForm = None

try:
    from reservas_app.models import Reserva
    from reservas_app.serializers import ReservaSerializer
    from reservas_app.forms import ReservaForm
except ImportError:
    Reserva = ReservaSerializer = ReservaForm = None


# ViewSets de la API
if Alojamiento:
    class AlojamientoViewSet(viewsets.ModelViewSet):
        queryset = Alojamiento.objects.all()
        serializer_class = AlojamientoSerializer

if Cabana:
    class CabanaViewSet(viewsets.ModelViewSet):
        queryset = Cabana.objects.all()
        serializer_class = CabanaSerializer

if Cliente:
    class ClienteViewSet(viewsets.ModelViewSet):
        queryset = Cliente.objects.all()
        serializer_class = ClienteSerializer

if Reserva:
    class ReservaViewSet(viewsets.ModelViewSet):
        queryset = Reserva.objects.all()
        serializer_class = ReservaSerializer


# -------------------------------------------------------------------------
# 2. VISTAS BASADAS EN CLASES (CBV) - CRUDs y TemplateViews
# -------------------------------------------------------------------------

class InicioView(TemplateView):
    template_name = "alojamientos_app/index.html"

class HomeView(TemplateView):
    template_name = "alojamientos_app/alojamientos_app.html"

class DashboardView(TemplateView):
    template_name = "alojamientos_app/dashboard.html"


# CRUD Alojamientos
if Alojamiento:
    class AlojamientoListView(ListView):
        model = Alojamiento
        template_name = "alojamientos_app/lista_alojamientos.html"
        context_object_name = "alojamientos"

    class AlojamientoDetailView(DetailView):
        model = Alojamiento
        template_name = "alojamientos_app/detalle_alojamiento.html"
        context_object_name = "alojamiento"

    class AlojamientoCreateView(CreateView):
        model = Alojamiento
        form_class = AlojamientoForm
        template_name = "alojamientos_app/crear.html"
        success_url = reverse_lazy("alojamientos_app:lista_alojamientos")

    class AlojamientoUpdateView(UpdateView):
        model = Alojamiento
        form_class = AlojamientoForm
        template_name = "alojamientos_app/editar.html"
        success_url = reverse_lazy("alojamientos_app:lista_alojamientos")

    class AlojamientoDeleteView(DeleteView):
        model = Alojamiento
        template_name = "alojamientos_app/alojamientos_app.html"
        success_url = reverse_lazy("alojamientos_app:lista_alojamientos")


# CRUD Cabañas
if Cabana:
    class CabanaListView(ListView):
        model = Cabana
        template_name = "cabanas_app/listar_cabanas.html"
        context_object_name = "cabanas"

    class CabanaDetailView(DetailView):
        model = Cabana
        template_name = "cabanas_app/detalle_cabana.html"
        context_object_name = "cabana"

    class CabanaCreateView(CreateView):
        model = Cabana
        form_class = CabanaForm
        template_name = "cabanas_app/crear_cabanas.html"
        success_url = reverse_lazy("cabanas_app:lista_cabanas")

    class CabanaUpdateView(UpdateView):
        model = Cabana
        form_class = CabanaForm
        template_name = "cabanas_app/editar_cabanas.html"
        success_url = reverse_lazy("cabanas_app:lista_cabanas")

    class CabanaDeleteView(DeleteView):
        model = Cabana
        template_name = "cabanas_app/eliminar_cabana.html"
        success_url = reverse_lazy("cabanas_app:lista_cabanas")


# CRUD Clientes y Reservas por Clases
if Cliente:
    class ClienteListView(ListView):
        model = Cliente
        template_name = "clientes_app/clientes_list.html"
        context_object_name = "clientes"

    class ClienteCreateView(CreateView):
        model = Cliente
        form_class = ClienteForm
        template_name = "clientes_app/crear_cliente.html"
        success_url = reverse_lazy("clientes_app:lista")

if Reserva:
    class ReservaListView(ListView):
        model = Reserva
        template_name = "reservas_app/reservas_list.html"
        context_object_name = "reservas"

    class ReservaCreateView(CreateView):
        model = Reserva
        form_class = ReservaForm
        template_name = "reservas_app/crear.html"
        success_url = reverse_lazy("reservas_app:lista")


# -------------------------------------------------------------------------
# 3. VISTAS BASADAS EN FUNCIONES (FBV) Y HELPERS GLOBALES
# -------------------------------------------------------------------------

def sistema_unificado(request: HttpRequest) -> HttpResponse:
    return render(request, "sistema_alojamiento/sistema_unificado.html")

def dashboard(request: HttpRequest) -> HttpResponse:
    return render(request, "desabord.html")

def inicio(request: HttpRequest) -> HttpResponse:
    return render(request, "index.html")

def crear_alojamiento(request: HttpRequest) -> HttpResponse:
    if request.method == "POST":
        return redirect("dashboard")
    return render(request, "crear_cliente.html")

def lista_alojamientos(request: HttpRequest) -> HttpResponse:
    alojamientos = Alojamiento.objects.all() if Alojamiento else []
    return render(request, "alojamientos_app/lista_alojamientos.html", {"alojamientos": alojamientos})

def cabana_views_set(request: HttpRequest) -> HttpResponse:
    return render(request, "cabanas.html")

def respuesta_root(request: HttpRequest) -> HttpResponse:
    return render(request, "clientes_app/base.html")

def cliente_detalles(request: HttpRequest, cliente_id: int) -> HttpResponse:
    cliente = get_object_or_404(Cliente, pk=cliente_id) if Cliente else None
    return render(request, "clientes_app/detalle.html", {"cliente": cliente})

def ClienteUpdateView(request: HttpRequest, pk: int) -> HttpResponse:
    cliente = get_object_or_404(Cliente, pk=pk) if Cliente else None
    if request.method == "POST" and ClienteForm:
        form = ClienteForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            return redirect("clientes_app:lista")
    else:
        form = ClienteForm(instance=cliente) if ClienteForm else None
    return render(request, "clientes_app/editar.html", {"form": form, "cliente": cliente})

def ClienteDeleteView(request: HttpRequest, pk: int) -> HttpResponse:
    cliente = get_object_or_404(Cliente, pk=pk) if Cliente else None
    if request.method == "POST" and cliente:
        cliente.delete()
        return redirect("clientes_app:lista")
    return render(request, "clientes_app/eliminar.html", {"cliente": cliente})